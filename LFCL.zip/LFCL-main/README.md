# LFCL
The code implements the "A Leader-Follower Contrastive Learning Framework for imbalanced Multimodal Remote Sensing Image Classification"
